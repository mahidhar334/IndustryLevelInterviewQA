# ServiceMax Configuration Explorer — Installation Guide

This extension lets you browse, search and retrieve ServiceMax configurations
from a Salesforce org inside VS Code, without typing commands.

This guide covers installing it on a new machine. There are two routes:

| Route | Who it's for | Time |
|---|---|---|
| **A — From the file bundle (zip)** | Everyone. **Use this one.** | ~15 min |
| **B — From Git** | Developers who want to change the code | ~25 min |

If you just want to *use* the extension, follow **Route A** and ignore Route B
entirely. Route B is not a better version — it is the same extension, built by
you instead of handed to you.

---

# Before you start (both routes)

You need three things on the machine. These are one-time steps.

## 1. VS Code

If it isn't installed: https://code.visualstudio.com/download

## 2. The Salesforce CLI

Download and run the installer:
https://developer.salesforce.com/tools/salesforcecli

Then **open a new terminal** — in VS Code: **Terminal → New Terminal** — and
type:

```
sf --version
```

You should see a version number, something like `@salesforce/cli/2.x.x`.

> **If you see "command not found" or "not recognized":** close the terminal
> and open a fresh one. The installer only affects terminals opened after it
> finishes. If it still fails, restart the machine.

## 3. The ServiceMax plugin for the CLI

In that same terminal:

```
sf plugins install svmxc-sf
```

> **You will be asked to confirm a plugin that "is not digitally signed".**
> That is expected and normal for this plugin. Type `y` and press Enter.

Check it worked:

```
sf svmxc --help
```

You should see a short help screen mentioning `retrieve`.

**You do not need to log in to Salesforce first.** The extension can do that
for you.

---

# Route A — Install from the file bundle (recommended)

## A1. Get the files

You will be given a folder or zip containing:

```
servicemax-configuration-explorer-0.1.9.vsix   <- the extension itself
INSTALL.md                                      <- this guide
CHECKSUMS.txt                                   <- to verify the file
RELEASE-NOTES.md                                <- what changed
```

If it arrived as a `.zip`, right-click it and choose **Extract All** first.
Don't try to install from inside the zip.

## A2. (Optional) Check the file wasn't damaged or altered

In a terminal, in the folder containing the `.vsix`:

```
certutil -hashfile servicemax-configuration-explorer-0.1.9.vsix SHA256
```

Compare the long code it prints with the one in `CHECKSUMS.txt`. They must
match exactly. If they don't, ask for the file again — don't install it.

## A3. Install the extension

In VS Code:

1. Click the **Extensions** icon in the left-hand bar (or press `Ctrl+Shift+X`)
2. Click the **`...`** menu at the top of the Extensions panel
3. Choose **Install from VSIX...**
4. Select the `.vsix` file
5. Wait for the confirmation message

That's it. Skip to **First run** below.

> Prefer the terminal? This does the same thing:
> ```
> code --install-extension servicemax-configuration-explorer-0.1.9.vsix
> ```

---

# Route B — Install from Git (developers only)

Use this only if you intend to modify the code. It produces exactly the same
extension as Route A.

### ⚠️ Before you copy this repository anywhere

The project folder contains **real data retrieved from a Salesforce org** —
several hundred configuration files, plus an org username and login address in
the `evidence/` folder. Treat the repository like org data, not like ordinary
source code:

- Don't push it to a **public** repository.
- Don't copy it to a machine that shouldn't hold that org's configuration.

If all you want is to run the extension on a work machine, **Route A carries
none of that data** — the `.vsix` contains only program code. Prefer it.

## B1. Extra prerequisite: Node.js

Route B needs Node.js (version 18 or newer): https://nodejs.org

Check it:

```
node --version
npm --version
```

## B2. Get the code

If the repository is hosted somewhere you have access to:

```
git clone <repository-url>
cd "VS CODE Extension SVMXC"
```

If you were handed the folder directly (USB, network share, zip), copy it to
the machine and open a terminal inside it.

## B3. Build the extension

```
npm install
npm run release
```

`npm install` downloads the build tools. `npm run release` compiles the code
and produces a fresh bundle in a `dist` folder:

```
dist/servicemax-configuration-explorer-0.1.9.vsix
dist/INSTALL.md
dist/CHECKSUMS.txt
dist/RELEASE-NOTES.md
```

## B4. Install it

```
code --install-extension dist/servicemax-configuration-explorer-0.1.9.vsix
```

Or use the VS Code UI as described in step **A3**.

> **Optional — check the build is healthy:** `npm test` runs the full test
> suite. It takes about 5 minutes because it makes real calls to a Salesforce
> org, and it expects you to be logged in to an org aliased `prodOrg`. It is
> not required in order to use the extension.

---

# First run (both routes)

## 1. Open a folder

**File → Open Folder**, and pick (or create) a folder such as
`Documents\ServiceMax`.

This matters: retrieved files are saved into whichever folder you have open.
Without one, the extension has nowhere to put them — it will tell you if you
forget.

## 2. Choose your org

Look at the **bottom of the VS Code window**. You should see:

```
⬇ Set source org        ⬆ No target org
```

Click **Set source org**.

- If you are already logged in to an org, pick it from the list.
- If not, choose **Log in to another org...**, then:
  1. Say whether it's a **Production/Developer org** or a **Sandbox**
     (or give your company's own login address)
  2. Give it a short name you'll recognise, e.g. `uatSandbox`
  3. Your browser opens — log in to Salesforce as normal
  4. Come back to VS Code; the org is selected automatically

**Source org** is where configurations are retrieved *from*. **Target org** is
optional — it's for comparing later. Nothing is ever sent to it.

## 3. Retrieve something

1. Click the **ServiceMax** icon in the left-hand bar
2. In the **Retrieve** section, click a type, e.g. **Wizard**
3. Type a few letters to search, tick what you want, press **Enter**
4. The files appear under **Retrieved Configurations**
5. Right-click any file → **Show Dependencies** to see what it uses, and why

To bring along everything a component depends on, turn on **"Also retrieve
everything these use"** using the icon in the search box before pressing Enter.

---

# Demo-day checklist

Run through this once *before* demonstrating, not during:

- [ ] `sf --version` works in a fresh terminal
- [ ] `sf svmxc --help` works
- [ ] The extension appears in the Extensions list as **ServiceMax
      Configuration Explorer**
- [ ] A folder is open in VS Code
- [ ] The source org at the bottom shows your org name, not "Set source org"
- [ ] You have retrieved at least one Wizard successfully
- [ ] **Show Dependencies** displays a tree for it

The first org click after opening VS Code can take a few seconds — the
Salesforce CLI is slow to start. Click it once while setting up, so it is warm
before you present.

---

# If something doesn't work

The extension explains problems in plain language. Read the message — it
usually names the fix. The common ones:

| What you see | What to do |
|---|---|
| "Salesforce CLI not found" | Finish step 2, then **restart VS Code**, not just the terminal. |
| "ServiceMax plugin not installed" | Run `sf plugins install svmxc-sf` and answer `y` to the unsigned prompt. |
| "Open a folder first" | **File → Open Folder** and pick any folder. |
| "You're not logged in to any Salesforce org yet" | Click **Log In** and follow the browser. |
| A type is greyed out | Hover it — it explains why. Some types are deliberately disabled because they haven't been fully verified. See `UNVERIFIED_CAPABILITIES.md`. |
| The orgs at the bottom don't appear | Reload with `Ctrl+Shift+P` → **Developer: Reload Window**. |
| Nothing happens after installing | Extensions don't activate in windows that were already open. Reload the window as above. |

**For anything else:** open **View → Output** and choose **ServiceMax** from
the dropdown on the right. That panel shows the real command that ran and the
real response from Salesforce. Copy that when reporting a problem — it is far
more useful than a screenshot of the error.

---

# Updating later

Installing a newer `.vsix` over an older one is all that's needed — VS Code
replaces the previous version. Reload the window afterwards
(`Ctrl+Shift+P` → **Developer: Reload Window**).

Check which version is installed with:

```
code --list-extensions --show-versions
```

Look for `local.servicemax-configuration-explorer@0.1.9`.
