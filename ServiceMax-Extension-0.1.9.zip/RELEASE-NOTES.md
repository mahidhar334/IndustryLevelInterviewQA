- **New: right-click any type in Retrieve → "Compare All of This Type with
  Target Org".** It fetches every component of that type from both orgs and
  summarises them as different / only in source / identical, with anything that
  exists only in the target flagged too.
- Pick any component from the results to open the differences side by side.
- This retrieves the entire type from both orgs, so it is slow by nature —
  expect tens of seconds. Comparing a single file (right-click a retrieved file)
  stays the quick option.
- Still read-only: nothing is sent to the target org.

Setup instructions are in INSTALL.md.
SHA-256: 0fa1244b5afaa26204a5d07212f7c0996210658ea2ebfb71fd3afaf4291f0f4a
