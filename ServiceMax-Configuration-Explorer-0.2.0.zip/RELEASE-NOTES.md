- **New: right-click a retrieved Expression → "Deploy to Target Org...".** It
  sends your local copy to the target org shown at the bottom of the window.
- **You are always asked first.** The question names the target org and the
  Expression, and says plainly that a deploy can't be undone from VS Code.
  Closing the question or pressing Escape cancels it.
- **Nothing is overwritten without a second yes.** If the Expression already
  exists in the target, it is left alone and you are asked separately whether
  to replace it.
- If the deploy quietly does nothing — which the ServiceMax CLI sometimes does
  without any message — you're told so, rather than shown a success.
- Only Expressions can be deployed for now; every other type shows
  "Deploy to Target Org (not available yet)" and says why when clicked.

- **Comparing Transactions between orgs now ignores internal record numbers.**
  Each org numbers page-layout items itself, so these always differed and
  buried the real changes. Only the fields that hold nothing but those numbers
  are ignored, and the output panel says how many were left out.
- Shorter, plainer popups throughout — deploy, overwrite, export and org
  reminders.

Setup instructions are in INSTALL.md.
SHA-256: cb59521b605143b3e5ef1dec7fa333eda6e688943031e189217a86aa3671d496
